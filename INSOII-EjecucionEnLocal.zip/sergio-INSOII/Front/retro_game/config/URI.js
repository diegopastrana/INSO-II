const API_BASE_URI = process.env.API_BASE_URI

module.exports = API_BASE_URI
