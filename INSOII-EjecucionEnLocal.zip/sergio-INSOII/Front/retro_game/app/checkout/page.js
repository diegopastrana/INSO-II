"use client"
import {CheckoutProvider} from '@stripe/react-stripe-js';
import {loadStripe} from '@stripe/stripe-js';
import CheckoutForm from './checkout';
import STRIPE_PK from '@/config/STRIPE_CONFIG';

const API_BASE_URI = "http://localhost:8080"

const stripePromise = loadStripe(STRIPE_PK);

const fetchClientSecret = () => {
  return fetch(`${API_BASE_URI}/api/create-payment-intent`, { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' }})
    .then((response) => response.json())
    .then((json) => json.clientSecret)
};

export default function App() {
  return (
    <CheckoutProvider stripe={stripePromise} options={{fetchClientSecret}}>
      <CheckoutForm />
    </CheckoutProvider>
  );
}
