import styles from "../page.module.css";

export default function PagoCompletado() {
  return (
    <div className={styles.container}>
      <h1 className={styles.titulo}>pago completado</h1>
    </div>
  );
}
