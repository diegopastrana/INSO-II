import API_BASE_URI from "@/config/URI";
import ClientHome from "../../clientHome";



export default async function Page({ params }) {
  const { page } = await params 
  const res = await fetch(`${API_BASE_URI}/api/games?page=${page}&size=12`);
  const data = await res.json();

  return <ClientHome initialGames={data} initialPage={page} />;
}
